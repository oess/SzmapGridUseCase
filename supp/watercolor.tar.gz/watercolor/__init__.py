###############################################################################
# Copyright (C) 2010, 2011, 2012, 2013 by OpenEye Scientific Software
###############################################################################
# set grid styles for SZMAP output
###############################################################################

from openeye import oechem
from openeye.oechem        import *
from openeye.vidaExtension import *

class WaterColorExtension(OEVidaExtension):

    def __init__(self, filePath):
        OEVidaExtension.__init__(self, filePath,
                                 command="watercolor.WaterColorExtension.Colorize()")

    def InitializeUI(self):
        pass

    @staticmethod
    def BackgroundIsDark():
        bkg = ViewerBackgroundColorGet()
        luminance = 0.2126 * bkg.GetR() + 0.7152 * bkg.GetG() + 0.0722 * bkg.GetG()
        if luminance > 127.5:
            return False
        return True

    @staticmethod
    def Colorize():
        id = WaterColorExtension.FindParentID()
        if not id == 0:
            WaterColorExtension.SetupWatercolorView(id)
            WaterColorExtension.SetAnnotationVisibility(id)

    @staticmethod
    def FindParentID(key = False):
        if not key:
            key = ActiveKey()
        molid = 0
        if KeyTypeGet(key) == "Mol":
            molid = KeyIDGet(key)
        else:
            molid = KeySourceIDGet(key)
            if molid == 0:
                return molid
        parentid = ListGetObjectLists(molid)[0]
        return parentid

    @staticmethod
    def SetupWatercolorView(parent):

        if WaterColorExtension.BackgroundIsDark():
            # lighter palette
            tin         = OEColor(127,127,127)
            white       = OEColor(255,255,255)
            spring      = OEColor(0  ,220,  0)
            spray       = OEColor(0  ,255,128)
            sprayLight  = OEColor(110,248,150)
            flora       = OEColor(102,255,102)
            sky         = OEColor(102,204,255)
            skyLight    = OEColor(138,207,251)
            aqua        = OEColor(0  ,128,255)
            cyan        = OEColor(0  ,255,255)
            turquoise   = OEColor(180,170,255)
            salmon      = OEColor(255, 81,102)
            salmonLight = OEColor(238,128,140)
            strawberry  = OEColor(255,  0,128)
            banana      = OEColor(255,255, 88)
            gold        = OEColor(255,170,  0)
            orange      = OEColor(255,230, 50)
            purple      = OEColor(255,100,230)
        else:
            # darker palette
            tin         = OEColor(110,110,110)
            white       = OEColor(0,    0,  0)
            spring      = OEColor(0  ,140,  0)
            spray       = OEColor(0  ,210,105)
            sprayLight  = OEColor( 80,200,110)
            flora       = OEColor( 70,210, 70)
            sky         = OEColor( 70,160,210)
            skyLight    = OEColor(100,160,210)
            aqua        = OEColor(0  ,105,210)
            cyan        = OEColor(0  ,210,210)
            turquoise   = OEColor(140,130,210)
            salmon      = OEColor(210, 55, 65)
            salmonLight = OEColor(200,105,110)
            strawberry  = OEColor(210,  0,105)
            banana      = OEColor(210,210, 60)
            gold        = OEColor(215,140,  0)
            orange      = OEColor(210,200, 20)
            purple      = OEColor(210, 70,200)

        cutoff = {"pnts" :  1.0,
                  "mask" :  0.5,
                  "inte" : -1.0,
                  "solv" :  1.0,
                  "vdwN" : -2.0,
                  "ivdw" : -0.01,
                  "bury" :  0.8,
                  "burN" : -0.1,
                  "burP" :  0.1,
                  "gh1N" : -0.5,
                  "ts1P" : -1.0,
                  "steN" : -0.5,
                  "sdeP" :  0.5,
                  "sdeN" : -0.5,
                  "steP" :  0.5,
                  "stcN" : -0.5,
                  "stcP" :  0.5,
                  "ddeN" : -1.5,
                  "ddeP" :  0.75,
                  "ordr" :  0.6,
                  "ordN" : -0.4,
                  "ordP" :  0.4}

        opaquePct =  0
        lowPct    =  5
        mediumPct = 50
        higherPct = 60

        #properties for each grid type, based on the grid name:
        # (makeSolid, (isoLevel, colorname, pctTransparency), ...)
        props = {"point_grid" :                   (False,(cutoff["pnts"], tin,      opaquePct)),
                 "apo_point_grid" :               (False,(cutoff["pnts"], tin,      opaquePct)),
                 "lig_point_grid" :               (False,(cutoff["pnts"], tin,      opaquePct)),
                 "stbl_point_grid" :              (False,(cutoff["pnts"], tin,      opaquePct)),
                 "free_energy_grid" :             (True, (cutoff["gh1N"], spray,    higherPct)),
                 "apo_free_energy_grid" :         (True, (cutoff["gh1N"], spray,    higherPct)),
                 "lig_free_energy_grid" :         (True, (cutoff["gh1N"], spray,    higherPct)),
                 "stbl_free_energy_grid" :        (False,(cutoff["steN"], orange,   opaquePct),
                                                         (cutoff["steP"], purple,   opaquePct)),
                 "neut_diff_free_energy_grid" :   (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_apo_free_energy_grid":(True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_lig_free_energy_grid":(True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_stbl_free_energy_grid":(False,(cutoff["sdeN"],orange,   opaquePct),
                                                          (cutoff["sdeP"],purple,   opaquePct)),
                 "vac_diff_free_energy_grid" :    (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_apo_free_energy_grid": (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_lig_free_energy_grid": (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_stbl_free_energy_grid":(False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "neutral_free_energy_grid" :     (False,(cutoff["gh1N"],sprayLight,lowPct)),
                 "neutral_apo_free_energy_grid" : (False,(cutoff["gh1N"],sprayLight,lowPct)),
                 "neutral_lig_free_energy_grid" : (False,(cutoff["gh1N"],sprayLight,lowPct)),
                 "neut_stbl_free_energy_grid" :   (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "vac_stbl_free_energy_grid" :    (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "diff_free_energy_grid" :        (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_apo_free_energy_grid" :    (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_lig_free_energy_grid" :    (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "stbl_neutral_free_energy_grid":(False, (cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "enthalpy_grid" :                (True, (cutoff["gh1N"], salmon,   higherPct)),
                 "apo_enthalpy_grid" :            (True, (cutoff["gh1N"], salmon,   higherPct)),
                 "lig_enthalpy_grid" :            (True, (cutoff["gh1N"], salmon,   higherPct)),
                 "stbl_enthalpy_grid" :           (False,(cutoff["steN"], orange,   opaquePct),
                                                         (cutoff["steP"], purple,   opaquePct)),
                 "neut_diff_enthalpy_grid" :      (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_apo_enthalpy_grid" :  (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_lig_enthalpy_grid" :  (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_stbl_enthalpy_grid" : (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "vac_diff_enthalpy_grid" :       (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_apo_enthalpy_grid" :   (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_lig_enthalpy_grid" :   (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "vac_diff_stbl_enthalpy_grid" :  (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "neutral_enthalpy_grid" :        (False,(cutoff["gh1N"],salmonLight,lowPct)),
                 "neutral_apo_enthalpy_grid" :    (False,(cutoff["gh1N"],salmonLight,lowPct)),
                 "neutral_lig_enthalpy_grid" :    (False,(cutoff["gh1N"],salmonLight,lowPct)),
                 "neut_stbl_enthalpy_grid" :      (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "vac_stbl_enthalpy_grid" :       (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "diff_enthalpy_grid" :           (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_apo_enthalpy_grid" :       (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_lig_enthalpy_grid" :       (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "stbl_neutral_enthalpy_grid" :   (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "entropy_grid" :                 (True, (cutoff["ts1P"], sky,      higherPct)),
                 "apo_entropy_grid" :             (True, (cutoff["ts1P"], sky,      higherPct)),
                 "lig_entropy_grid" :             (True, (cutoff["ts1P"], sky,      higherPct)),
                 "stbl_entropy_grid" :            (False,(cutoff["steN"], orange,   opaquePct),
                                                         (cutoff["steP"], purple,   opaquePct)),
                 "neut_diff_entropy_grid" :       (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_apo_entropy_grid" :   (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_lig_entropy_grid" :   (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "neut_diff_stbl_entropy_grid" :  (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "vac_diff_stbl_entropy_grid" :   (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "neutral_entropy_grid" :         (False,(cutoff["ts1P"], skyLight, lowPct)),
                 "neutral_apo_entropy_grid" :     (False,(cutoff["ts1P"], skyLight, lowPct)),
                 "neutral_lig_entropy_grid" :     (False,(cutoff["ts1P"], skyLight, lowPct)),
                 "neut_stbl_entropy_grid" :       (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "vac_stbl_entropy_grid" :        (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "diff_entropy_grid" :            (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_apo_entropy_grid" :        (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "diff_lig_entropy_grid" :        (True, (cutoff["ddeN"], orange,   mediumPct),
                                                         (cutoff["ddeP"], purple,   mediumPct)),
                 "stbl_neutral_entropy_grid" :    (False,(cutoff["sdeN"], orange,   opaquePct),
                                                         (cutoff["sdeP"], purple,   opaquePct)),
                 "interaction_grid" :             (False,(cutoff["inte"], white,    opaquePct)),
                 "apo_interaction_grid" :         (False,(cutoff["inte"], white,    opaquePct)),
                 "lig_interaction_grid" :         (False,(cutoff["inte"], white,    opaquePct)),
                 "stbl_interaction_grid" :        (False,(cutoff["stcN"], orange,   opaquePct),
                                                         (cutoff["stcP"], purple,   opaquePct)),
                 "psolv_grid" :                   (False,(cutoff["solv"],strawberry,opaquePct)),
                 "apo_psolv_grid" :               (False,(cutoff["solv"],strawberry,opaquePct)),
                 "lig_psolv_grid" :               (False,(cutoff["solv"],strawberry,opaquePct)),
                 "stbl_psolv_grid" :              (False,(cutoff["stcN"], orange,   opaquePct),
                                                         (cutoff["stcP"], purple,   opaquePct)),
                 "wsolv_grid" :                   (False,(cutoff["solv"], turquoise,opaquePct)),
                 "apo_wsolv_grid" :               (False,(cutoff["solv"], turquoise,opaquePct)),
                 "lig_wsolv_grid" :               (False,(cutoff["solv"], turquoise,opaquePct)),
                 "stbl_wsolv_grid" :              (False,(cutoff["stcN"], orange,   opaquePct),
                                                         (cutoff["stcP"], purple,   opaquePct)),
                 "vdw_grid" :                     (True, (cutoff["vdwN"], spring,   mediumPct)),
                 "apo_vdw_grid" :                 (True, (cutoff["vdwN"], spring,   mediumPct)),
                 "lig_vdw_grid" :                 (True, (cutoff["vdwN"], spring,   mediumPct)),
                 "stbl_vdw_grid" :                (False,(cutoff["stcN"], orange,   opaquePct),
                                                         (cutoff["stcP"], purple,   opaquePct)),
                 "intvdw_grid" :                  (False,(cutoff["ivdw"], gold,     opaquePct)),
                 "apo_intvdw_grid" :              (False,(cutoff["ivdw"], gold,     opaquePct)),
                 "lig_intvdw_grid" :              (False,(cutoff["ivdw"], gold,     opaquePct)),
                 "stbl_intvdw_grid" :             (False,(cutoff["stcN"], orange,   opaquePct),
                                                         (cutoff["stcP"], purple,   opaquePct)),
                 "mask_grid" :                    (False,(cutoff["mask"], tin,      opaquePct)),
                 "apo_mask_grid" :                (False,(cutoff["mask"], tin,      opaquePct)),
                 "lig_mask_grid" :                (False,(cutoff["mask"], tin,      opaquePct)),
                 "vdw_mask_grid" :                (False,(cutoff["mask"], tin,      opaquePct)),
                 "stbl_mask_grid" :               (False,(cutoff["mask"], tin,      opaquePct)),
                 "apo_vdw_mask_grid" :            (False,(cutoff["mask"], tin,      opaquePct)),
                 "lig_vdw_mask_grid" :            (False,(cutoff["mask"], tin,      opaquePct)),
                 "probe_burial_grid" :            (True, (cutoff["bury"], aqua,     mediumPct)),
                 "apo_probe_burial_grid" :        (True, (cutoff["bury"], aqua,     mediumPct)),
                 "lig_probe_burial_grid" :        (True, (cutoff["bury"], aqua,     mediumPct)),
                 "stbl_probe_burial_grid" :       (False,(cutoff["burN"], orange,   opaquePct),
                                                         (cutoff["burP"], purple,   opaquePct)),
                 "order_grid" :                   (False,(cutoff["ordr"], cyan,     opaquePct)),
                 "apo_order_grid" :               (False,(cutoff["ordr"], cyan,     opaquePct)),
                 "lig_order_grid" :               (False,(cutoff["ordr"], cyan,     opaquePct)),
                 "stbl_order_grid" :              (False,(cutoff["ordN"], orange,   opaquePct),
                                                         (cutoff["ordP"], purple,   opaquePct)) }
        PushIgnoreHint(True)
        try:
            apoId = None
            ligId = None
            at1Id = None

            hasSurface = False

            molids = ListGetObjects(parent)
            gridKeys = []
            for molId in molids:
                kidList = list(ChildrenGet(molId))
                for key in kidList:
                     if IsASurface(key):
                        hasSurface = True
                        break
                     if not NameGet(key) == "probe":
                         gridName = ObjectNameGet(key)
                         if gridName in props:
                             gridKeys.append(key)

                if not hasSurface:
                    molKey = KeysGet(molId)[0]
                    if IsAMolecule(molKey) and molKey.IsValid():
                       if apoId == None and "apo:" in NameGet(molKey) \
                               and not "at_coords" in NameGet(molKey):
                           apoId = molId
                       elif ligId == None and "ligand:" in NameGet(molKey) \
                                    and not "at_coords" in NameGet(molKey):
                           ligId = molId
                       elif at1Id == None and "apo:" in NameGet(molKey) \
                                     and "at_coords" in NameGet(molKey):
                           at1Id = molId  # first at coords mol

            if len(gridKeys) > 0:

                if ligId == None and not at1Id == None:
                    ligId = at1Id
                if (not hasSurface) and (not apoId == None) and (not ligId == None):
                    WaterColorExtension.FocusProteinDisplay(apoId, ligId)

                CenterSet(gridKeys[0])

                GridShowCornersSet(False)

                for i in gridKeys:

                    gridName = ObjectNameGet(i)

                    #look up properties for grid based on grid name
                    gridprops = props[gridName]
                    gridID = KeyIDGet(i)

                    #apply properties to grid
                    ContourDrawAsSurfaceSet(gridID, gridprops[0])

                    contourIdx = 0
                    for aspect in gridprops[1:]:
                        isoLevel = aspect[0]

                        tint = aspect[1]
                        # set the transparency for the tint
                        tint.SetA(int(0.5 + (1.0 - aspect[2]*0.01)*255.0))

                        levels = ContourGetAll(gridID)
                        if contourIdx < 1 or len(levels) > 1: # modify the contour
                            ContourLevelForIndexSet(gridID, contourIdx, isoLevel)
                            ContourColorForIndexSet(gridID, contourIdx, tint)
                        else: # create an additional contour
                            ContourCreate(gridID, isoLevel, tint)

                        contourIdx += 1
        finally:
            PopIgnoreHint()

    @staticmethod
    def SetAnnotationVisibility(parent):
        try:
            PushIgnoreHint(True)

            molids = ListGetObjects(parent)
            hasSurface = False

            # Lock(molids[0],True)
            # print molids[0]
            # CenterSet(KeysGet(molids[0])[0])
            
            kidKeys = []
            for molId in molids:
                molKey = KeysGet(molId)[0]
                if IsAMolecule(molKey) and molKey.IsValid():
                    mol = OEMol()
                    MoleculeExamine(mol, molKey)
                    if not mol.HasData("gameplan"):
                        return # not what we are searching for

                kidList = list(ChildrenGet(molId))
                for key in kidList:
                    if not NameGet(key) == "probe" and not IsASurface(key):
                         kidKeys.append(key)
                    if IsASurface(key):
                        hasSurface = True

            Active(molids[0])
            #ViewerFit()
            if not hasSurface:
                WaterColorExtension.FocusProteinDisplay(molids[1], molids[0])
            # Lock(molids[-1],True)

            MimicParentVisibilitySet(kidKeys, True)
        
        finally:
            PopIgnoreHint()

    @staticmethod
    def RestrictSelectionToMolID(molID):
        for atomKey in GetSelectedAtoms():
            if not (KeyParentIDGet(atomKey) == molID):
                Select(atomKey, False)
        for bondKey in GetSelectedBonds():
            if not (KeyParentIDGet(bondKey) == molID):
                Select(bondKey, False)

    @staticmethod
    def FocusProteinDisplay(proteinID, ligandID):
        surfaceID = None
        if proteinID:
            try:
                PushIgnoreHint(1)
                ClearSelection()
                Select(proteinID, True)
                MoleculeStyleSetScoped("wireframe",SelectedScope)

                Visible(proteinID, True)

                ClearSelection()
                Select(ligandID, True)
                SelectWithin(5.0, True)
                SelectInvert()
                WaterColorExtension.RestrictSelectionToMolID(proteinID)
                MoleculeStyleSetScoped("hidden",SelectedScope)

                if surfaceID == None:
                    proteinKey = KeysGet(proteinID)[0]
                    ligandKey = KeysGet(ligandID)[0]
                    surfaceID = SurfaceCreate("molecular", proteinKey, False)
                    if not surfaceID == 0:
                        surfaceKey = KeysGet(surfaceID)[0]
                        SurfaceCropDistanceFrom(surfaceKey, ligandKey, 6.0)
                        SurfaceAlterTransparency(surfaceID, 40)
                        # SurfaceColorBy(surfaceKey, "electrostatics")
                        Select(surfaceID, False)
                        Visible(surfaceID, False)
                        MimicParentVisibilitySet(surfaceKey, False)
                        ClearSelection()

                ClearSelection()
            finally:
                PopIgnoreHint()

#end of extension

ext = WaterColorExtension(__file__)
